function add(a,b){
    print("generating sum...")
    return a + b
}