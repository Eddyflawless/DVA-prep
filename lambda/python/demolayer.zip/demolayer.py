def add(a,b):
    print(f"generating sum of {a} + {b}")
    return a + b